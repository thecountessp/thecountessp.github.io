<?php echo '
  <ul class="nav my-nav bg-dark">
    <li class="nav-item"><a class="nav-link" href="./about.php">About</a></li>
    <li class="nav-item"><a class="nav-link" href="./contact.php">Contact</a></li>
  </ul>
';
?>