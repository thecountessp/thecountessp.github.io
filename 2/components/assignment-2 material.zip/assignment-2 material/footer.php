<?php echo '      
      <footer class="m-4">
        <p class="text-center text-muted">&copy; 2021 DM6103 Example PHP Website</p>
      </footer>'
?>